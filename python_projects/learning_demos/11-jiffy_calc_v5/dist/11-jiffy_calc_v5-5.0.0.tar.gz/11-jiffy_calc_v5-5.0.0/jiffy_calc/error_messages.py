# Functions for displaying error messages.
def zero_value():
    message = 'All values must be greater than zero!'
    return message


def negative_value():
    message = 'No negative values can be used!'
    return message


def invalid_value():
    message = 'The input is not a valid integer!'
    return message


def invalid_type():
    message = 'Improper Data Type Used'
    return message
