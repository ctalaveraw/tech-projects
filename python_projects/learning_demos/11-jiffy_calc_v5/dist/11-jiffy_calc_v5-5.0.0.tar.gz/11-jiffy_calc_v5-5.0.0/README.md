
# README

This is a basic unit conversion calculator that takes a number, as well as a supported unit and convert from Jiffy to another unit.

  

Features:


 - Error catching
- Input validation
- Usage of lists and loops
- Exit program with keyword


Learned how to make a package from [here](https://python-packaging-tutorial.readthedocs.io/en/latest/setup_py.html).