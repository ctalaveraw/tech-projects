# Global variables are defined here

continue_message = str('Tap any key!\n')
terminate_program = str('exit')


# A function representing the continue message will be created.
def continue_program():
    input(continue_message)
